package br.com.cursoudemy.productapi.modules.category.dto;

import lombok.Data;

@Data
public class CategoryRequest {

    private String description;
}
