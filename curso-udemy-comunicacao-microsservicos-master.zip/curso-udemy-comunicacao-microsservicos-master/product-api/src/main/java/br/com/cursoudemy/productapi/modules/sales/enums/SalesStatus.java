package br.com.cursoudemy.productapi.modules.sales.enums;

public enum SalesStatus {

    APPROVED,
    REJECTED
}
