package br.com.cursoudemy.productapi.modules.supplier.dto;

import lombok.Data;

@Data
public class SupplierRequest {

    private String name;
}
